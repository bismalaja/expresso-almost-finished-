from . import views
from django.urls import path

urlpatterns= [
    path("", views.dashboard, name="dashboard"),
]

urlpatterns+= [
    path("dashboard/", views.dashboard, name="dashboard"),
]

urlpatterns+= [
    path("trains/", views.trains, name="trains"),
    path("tickets/", views.tickets, name="tickets"),
    path("membership/", views.membership, name="membership"),
]