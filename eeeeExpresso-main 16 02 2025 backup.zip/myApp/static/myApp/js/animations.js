// document.querySelectorAll('.route').forEach(route => {
//     route.addEventListener('mouseenter', () => {
//         const table = route.querySelector('table');
//         table.style.opacity = '1';
//         table.style.height = 'auto';
//     });

//     route.addEventListener('mouseleave', () => {
//         const table = route.querySelector('table');
//         table.style.opacity = '0';
//         table.style.height = '0';
//     });
// });