// Function to handle dropdown option selection
function handleOption(option, route) {
  alert(`You selected: ${option} for ${route}`);
}