from django.shortcuts import render
from .models import TrainRoute

def index(request):
    context= {}
    return render(request, "myApp/index.html", context)

def dashboard(request):
    
    routes = TrainRoute.objects.all()
    return render(request, "myApp/dashboard.html",{"routes": routes})

def trains(request):
    routes = TrainRoute.objects.all()
    return render(request, "myApp/trains.html", {"routes": routes})

def tickets(request):
    context= {}
    return render(request, "myApp/tickets.html", context)

def membership(request):
    context= {}
    return render(request, "myApp/membership.html", context)