from django.contrib import admin
from .models import TrainRoute, Station

class StationInline(admin.TabularInline):
    model = Station
    extra = 1 

@admin.register(TrainRoute)
class TrainRouteAdmin(admin.ModelAdmin):
    inlines = [StationInline]

@admin.register(Station)
class StationAdmin(admin.ModelAdmin):
    list_display = ('name', 'route', 'order')
    list_filter = ('route',)