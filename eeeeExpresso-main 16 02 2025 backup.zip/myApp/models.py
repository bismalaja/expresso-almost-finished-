from django.db import models

class TrainRoute(models.Model):
    destination = models.CharField(max_length=255)
    distance = models.IntegerField(help_text="Distance in km")
    price = models.IntegerField(help_text="Price in euros")
    departure_time = models.TimeField(help_text="Departure time")
    spaces_left = models.PositiveIntegerField(default=200)

    def get_stops_list(self):
        """Returns an ordered list of station names."""
        return [station.name for station in self.stations.all()]

    def __str__(self):
        return self.destination

class Station(models.Model):
    name = models.CharField(max_length=255)
    route = models.ForeignKey(
        TrainRoute,
        on_delete=models.CASCADE,
        related_name='stations'
    )
    order = models.PositiveIntegerField(help_text="Order in the route")

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.order}. {self.name}"